The sieve benchmark does not require a `base/` directory.
The 2 files `main.rkt` and `streams.rkt` are self-contained.

The run script, however, demands a `base/` directory.
Hence this init file, to get git to commit this directory.
