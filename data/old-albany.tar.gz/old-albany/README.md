old-albany
===

Past data from the `albany` machine.
Run with 20 cores or something.
